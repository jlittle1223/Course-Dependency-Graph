# HackUCI
UCI Hackathon
